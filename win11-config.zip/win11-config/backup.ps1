# Backup-Configs.ps1
# Creates a portable backup bundle in a folder next to this script.

$ErrorActionPreference = "Stop"

function Write-Info($msg)  { Write-Host "[INFO]  $msg" -ForegroundColor Cyan }
function Write-Warn($msg)  { Write-Host "[WARN]  $msg" -ForegroundColor Yellow }
function Write-Ok($msg)    { Write-Host "[OK]    $msg" -ForegroundColor Green }

$Root = $PSScriptRoot
$Out  = Join-Path $Root "BackupBundle"

# Create folder structure
$dirs = @(
  $Out,
  (Join-Path $Out "PowerToys"),
  (Join-Path $Out "PowerToys\Registry"),
  (Join-Path $Out "PowerToys\Files"),
  (Join-Path $Out "WinGet"),
  (Join-Path $Out "Windows"),
  (Join-Path $Out "Windows\StartLayout"),
  (Join-Path $Out "Windows\Registry"),
  (Join-Path $Out "Apps")
)
foreach ($d in $dirs) { if (-not (Test-Path $d)) { New-Item -ItemType Directory -Path $d | Out-Null } }

Write-Info "Backup target: $Out"

# -------------------------
# 1) winget export (app list)
# -------------------------
try {
  $wg = Get-Command winget -ErrorAction Stop
  $wgOut = Join-Path $Out "WinGet\winget-packages.json"
  Write-Info "Exporting winget packages to $wgOut"
  # --include-unknown helps include apps not from winget sources (if supported by your winget version)
  & winget export -o $wgOut --accept-source-agreements | Out-Null
  Write-Ok "winget export complete"
}
catch {
  Write-Warn "winget export skipped (winget not found or failed): $($_.Exception.Message)"
}

# -------------------------
# 2) PowerToys backup
#    - Copy settings folder
#    - Export HKCU registry branch
#    - Copy built-in backup folder if present
# -------------------------
# PowerToys local settings folder (commonly under LocalAppData)
$ptLocal = Join-Path $env:LOCALAPPDATA "Microsoft\PowerToys"
$ptDst   = Join-Path $Out "PowerToys\Files\LocalAppData-Microsoft-PowerToys"

if (Test-Path $ptLocal) {
  Write-Info "Copying PowerToys files: $ptLocal -> $ptDst"
  if (Test-Path $ptDst) { Remove-Item $ptDst -Recurse -Force }
  Copy-Item $ptLocal $ptDst -Recurse -Force
  Write-Ok "PowerToys files copied"
} else {
  Write-Warn "PowerToys folder not found at: $ptLocal"
}

# PowerToys registry export (HKCU\Software\Microsoft\PowerToys)
$ptRegPath = "HKCU\Software\Microsoft\PowerToys"
$ptRegFile = Join-Path $Out "PowerToys\Registry\PowerToys-HKCU.reg"
try {
  Write-Info "Exporting PowerToys registry: $ptRegPath -> $ptRegFile"
  & reg.exe export $ptRegPath $ptRegFile /y | Out-Null
  Write-Ok "PowerToys registry exported"
}
catch {
  Write-Warn "PowerToys registry export failed/skipped: $($_.Exception.Message)"
}

# PowerToys built-in backup folder default: Documents\PowerToys\Backup (if you used the in-app Backup feature)
# (PowerToys provides Backup/Restore and default location is under Documents) [1](https://www.thewindowsclub.com/back-up-and-restore-powertoys-settings)[2](https://pureinfotech.com/backup-powertoys-settings-windows-11/)
$ptDocBackup = Join-Path $env:USERPROFILE "Documents\PowerToys\Backup"
$ptDocDst    = Join-Path $Out "PowerToys\Files\Documents-PowerToys-Backup"
if (Test-Path $ptDocBackup) {
  Write-Info "Copying PowerToys built-in backups: $ptDocBackup -> $ptDocDst"
  if (Test-Path $ptDocDst) { Remove-Item $ptDocDst -Recurse -Force }
  Copy-Item $ptDocBackup $ptDocDst -Recurse -Force
  Write-Ok "PowerToys built-in backup copied"
} else {
  Write-Info "No PowerToys built-in backup folder found (this is OK if you never used the Backup button)."
}

# -------------------------
# 3) Windows “settings” (portable subset)
#    - Start layout export
#    - Windows Terminal settings.json copy
#    - Export a few common HKCU personalization keys
# -------------------------

# 3a) Start layout export (creates .xml) [4](https://learn.microsoft.com/en-us/powershell/module/startlayout/export-startlayout?view=windowsserver2025-ps)
try {
  $startLayoutFile = Join-Path $Out "Windows\StartLayout\StartLayout.xml"
  Write-Info "Exporting Start layout to $startLayoutFile"
  Export-StartLayout -Path $startLayoutFile | Out-Null
  Write-Ok "Start layout exported"
}
catch {
  Write-Warn "Start layout export skipped/failed: $($_.Exception.Message)"
}

# 3b) Windows Terminal settings.json copy (Store packaged path) [5](https://stackoverflow.com/questions/63101571/where-is-the-windows-terminal-settings-location)
$wt1 = Join-Path $env:LOCALAPPDATA "Packages\Microsoft.WindowsTerminal_8wekyb3d8bbwe\LocalState\settings.json"
$wt2 = Join-Path $env:LOCALAPPDATA "Packages\Microsoft.WindowsTerminalPreview_8wekyb3d8bbwe\LocalState\settings.json"
$wt3 = Join-Path $env:LOCALAPPDATA "Microsoft\Windows Terminal\settings.json"

$wtFound = $null
foreach ($p in @($wt1,$wt2,$wt3)) { if (Test-Path $p) { $wtFound = $p; break } }

if ($wtFound) {
  $wtDst = Join-Path $Out "Apps\WindowsTerminal-settings.json"
  Write-Info "Copying Windows Terminal settings: $wtFound -> $wtDst"
  Copy-Item $wtFound $wtDst -Force
  Write-Ok "Windows Terminal settings copied"
} else {
  Write-Info "Windows Terminal settings.json not found (skipping)."
}

# 3c) Export a few common HKCU personalization keys (safe, user-scope)
# These are optional conveniences; remove if you want ultra-minimal registry changes.
$regExports = @(
  @{ Key="HKCU\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize"; File="Personalize.reg" },
  @{ Key="HKCU\Control Panel\Desktop"; File="Desktop.reg" },
  @{ Key="HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced"; File="ExplorerAdvanced.reg" },

  # Taskbar Search mode (hide/search icon/search box)
  @{ Key="HKCU\Software\Microsoft\Windows\CurrentVersion\Search"; File="Search.reg" }
)

foreach ($re in $regExports) {
  $dst = Join-Path $Out ("Windows\Registry\" + $re.File)
  try {
    Write-Info "Exporting $($re.Key) -> $dst"
    & reg.exe export $re.Key $dst /y | Out-Null
    Write-Ok "Exported $($re.File)"
  }
  catch {
    Write-Warn "Registry export failed/skipped for $($re.Key): $($_.Exception.Message)"
  }
}

Write-Ok "Backup complete. Bundle created at: $Out"
Write-Info "Copy the entire 'BackupBundle' folder to the new computer (same relative location to the restore script)."
