# Restore-Configs.ps1
# Restores configs from a bundle folder next to this script.

$ErrorActionPreference = "Stop"

function Write-Info($msg)  { Write-Host "[INFO]  $msg" -ForegroundColor Cyan }
function Write-Warn($msg)  { Write-Host "[WARN]  $msg" -ForegroundColor Yellow }
function Write-Ok($msg)    { Write-Host "[OK]    $msg" -ForegroundColor Green }

$Root = $PSScriptRoot
$In   = Join-Path $Root "BackupBundle"

if (-not (Test-Path $In)) {
  throw "BackupBundle folder not found at: $In"
}

Write-Info "Restore source: $In"

# -------------------------
# 1) PowerToys restore
#    - Import HKCU reg
#    - Copy files back
# -------------------------
# Import PowerToys registry
$ptRegFile = Join-Path $In "PowerToys\Registry\PowerToys-HKCU.reg"
if (Test-Path $ptRegFile) {
  try {
    Write-Info "Importing PowerToys registry: $ptRegFile"
    & reg.exe import $ptRegFile | Out-Null
    Write-Ok "PowerToys registry imported"
  } catch {
    Write-Warn "PowerToys registry import failed: $($_.Exception.Message)"
  }
} else {
  Write-Info "PowerToys registry file not found (skipping)."
}

# Copy PowerToys LocalAppData files back
$ptSrc = Join-Path $In "PowerToys\Files\LocalAppData-Microsoft-PowerToys"
$ptDst = Join-Path $env:LOCALAPPDATA "Microsoft\PowerToys"

if (Test-Path $ptSrc) {
  try {
    Write-Info "Stopping PowerToys (if running)..."
    Get-Process PowerToys* -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue

    Write-Info "Restoring PowerToys files: $ptSrc -> $ptDst"
    if (Test-Path $ptDst) { Remove-Item $ptDst -Recurse -Force }
    Copy-Item $ptSrc $ptDst -Recurse -Force
    Write-Ok "PowerToys files restored"
  } catch {
    Write-Warn "PowerToys file restore failed: $($_.Exception.Message)"
  }
} else {
  Write-Info "PowerToys files folder not found in bundle (skipping)."
}

# Restore PowerToys built-in backup folder (optional)
# (PowerToys supports backups under Documents by default) [1](https://www.thewindowsclub.com/back-up-and-restore-powertoys-settings)[2](https://pureinfotech.com/backup-powertoys-settings-windows-11/)
$ptDocSrc = Join-Path $In "PowerToys\Files\Documents-PowerToys-Backup"
$ptDocDst = Join-Path $env:USERPROFILE "Documents\PowerToys\Backup"
if (Test-Path $ptDocSrc) {
  try {
    Write-Info "Restoring PowerToys backup folder: $ptDocSrc -> $ptDocDst"
    if (-not (Test-Path (Split-Path $ptDocDst))) { New-Item -ItemType Directory -Path (Split-Path $ptDocDst) | Out-Null }
    if (Test-Path $ptDocDst) { Remove-Item $ptDocDst -Recurse -Force }
    Copy-Item $ptDocSrc $ptDocDst -Recurse -Force
    Write-Ok "PowerToys backup folder restored"
  } catch {
    Write-Warn "PowerToys backup folder restore failed: $($_.Exception.Message)"
  }
}

# -------------------------
# 2) Windows “settings” restore (portable subset)
#    - Import HKCU reg files
#    - Restore Windows Terminal settings.json
# -------------------------
$winRegDir = Join-Path $In "Windows\Registry"
if (Test-Path $winRegDir) {
  Get-ChildItem $winRegDir -Filter *.reg -File | ForEach-Object {
    try {
      Write-Info "Importing registry: $($_.FullName)"
      & reg.exe import $_.FullName | Out-Null
      Write-Ok "Imported $($_.Name)"
    } catch {
      Write-Warn "Registry import failed for $($_.Name): $($_.Exception.Message)"
    }
  }
} else {
  Write-Info "No Windows registry exports found (skipping)."
}

# Windows Terminal settings restore [5](https://stackoverflow.com/questions/63101571/where-is-the-windows-terminal-settings-location)
$wtBundle = Join-Path $In "Apps\WindowsTerminal-settings.json"
if (Test-Path $wtBundle) {
  $wt1 = Join-Path $env:LOCALAPPDATA "Packages\Microsoft.WindowsTerminal_8wekyb3d8bbwe\LocalState\settings.json"
  $wt2 = Join-Path $env:LOCALAPPDATA "Packages\Microsoft.WindowsTerminalPreview_8wekyb3d8bbwe\LocalState\settings.json"
  $wt3 = Join-Path $env:LOCALAPPDATA "Microsoft\Windows Terminal\settings.json"

  # Choose the first existing target folder; otherwise default to stable packaged folder
  $targets = @($wt1,$wt2,$wt3)
  $target = $targets | Where-Object { Test-Path (Split-Path $_) } | Select-Object -First 1
  if (-not $target) { $target = $wt1 }

  try {
    $tDir = Split-Path $target
    if (-not (Test-Path $tDir)) { New-Item -ItemType Directory -Path $tDir -Force | Out-Null }
    Write-Info "Restoring Windows Terminal settings -> $target"
    Copy-Item $wtBundle $target -Force
    Write-Ok "Windows Terminal settings restored"
  } catch {
    Write-Warn "Windows Terminal restore failed: $($_.Exception.Message)"
  }
} else {
  Write-Info "No Windows Terminal settings in bundle (skipping)."
}

# Start layout: exported for reference
# Import-StartLayout is NOT supported on Windows 11 in the same way for per-user customization; commonly deployed via policy/management.
# So we leave StartLayout.xml in the bundle for you/your management process. [4](https://learn.microsoft.com/en-us/powershell/module/startlayout/export-startlayout?view=windowsserver2025-ps)
$startLayoutFile = Join-Path $In "Windows\StartLayout\StartLayout.xml"
if (Test-Path $startLayoutFile) {
  Write-Info "StartLayout.xml is present at: $startLayoutFile"
  Write-Info "Note: Applying Start layout is typically done via management/policy on modern Windows; file kept for reference."
}

# -------------------------
# 3) winget import (install apps)
# -------------------------
$wgIn = Join-Path $In "WinGet\winget-packages.json"
if (Test-Path $wgIn) {
  try {
    $wg = Get-Command winget -ErrorAction Stop
    Write-Info "Importing winget packages from $wgIn"
    # Options documented by Microsoft: accept agreements, ignore unavailable, etc. [3](https://learn.microsoft.com/en-us/windows/package-manager/winget/import)
    & winget import -i $wgIn --accept-source-agreements --accept-package-agreements --ignore-unavailable | Out-Null
    Write-Ok "winget import complete"
  } catch {
    Write-Warn "winget import failed/skipped: $($_.Exception.Message)"
  }
} else {
  Write-Info "No winget export JSON found in bundle (skipping)."
}

Write-Ok "Restore complete."
Write-Info "For PowerToys: launch PowerToys once to confirm settings; you may need to restart it if it was running."
Write-Info "Some Windows UI settings may require sign-out/sign-in to fully apply."
